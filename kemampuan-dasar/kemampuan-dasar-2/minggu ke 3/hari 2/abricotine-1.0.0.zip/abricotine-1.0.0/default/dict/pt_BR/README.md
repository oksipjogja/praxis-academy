## Brazilian Portuguese dictionary

This is a Brazilian Portuguese dictionary for Hunspell. Last updated on September, 2010.

This program is free software. You can redistribute it and/or modify it under the terms of the GNU General Public License (version 2.1) as published by the Free Software Foundation.

LGPL 2.1 2006 - 2010  by Raimundo Santos Moura <raimundomoura@openoffice.org>