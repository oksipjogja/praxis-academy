11/01/2017 release.

---

# Estensione linguistica italiana - Italian Writing Aids extension
Forked from: Dizionario italiano, see README.txt for details

Copyright (C) 2001, 2002 Gianluca Turconi
Copyright (C) 2002, 2003, 2004 Gianluca Turconi and Davide Prina
Copyright (C) 2004, 2005, 2006, 2007  Davide Prina
Copyright (C) 2010, 2011 Andrea Pescetti

E-Mail: pescetti<AT>openoffice<DOT>org
Home: http://extensions.services.openoffice.org/project/dict-it
License: GNU GPL 3

Version 3.3.1 (24/03/2011) (DD/MM/YYYY)

This file is distributed under the GPL license.

This file is part of the "Estensione linguistica italiana - Italian
Writing Aids extension".

The "Estensione linguistica italiana - Italian Writing Aids extension"
is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License, version 3,
as published by the Free Software Foundation.

The "Estensione linguistica italiana - Italian Writing Aids extension"
is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with the "Estensione linguistica italiana - Italian
Writing Aids extension"; if not, see <http://www.gnu.org/licenses/>.